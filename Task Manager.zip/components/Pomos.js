import React from 'react'

function Pomos() {
  return (
    <div className="mt-4 text-white bg-red-300 rounded p-5 w-96 m-auto text-center">
        Pomos: 1/2 Finish At: 21:09
    </div>
  )
}

export default Pomos