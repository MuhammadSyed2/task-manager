import React from 'react'

function Settings({close}) {
	let data = {pomo:25, sb:5, lb:15}
	function save (){
		close && close()
	}
  return (
    <>
        Time (Minutes)
		<div className="w-full flex gap-3">
			<span className="flex flex-col gap-1">pomodoro <input value={data.pomo}/></span>
			<span className="flex flex-col gap-1">short break <input value={data.sb}/></span>
			<span className="flex flex-col gap-1 ">long break <input value={data.lb}/></span>
		</div>
		Alarm 
		<div className="w-full flex gap-3">
			<span className="flex flex-col gap-1">pomodoro <input value={data.pomo}/></span>
			<span className="flex flex-col gap-1">short break <input value={data.sb}/></span>
			<span className="flex flex-col gap-1">long break <input value={data.lb}/></span>
		</div>

    </>
  )
}

export default Settings