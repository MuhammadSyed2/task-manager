
function Toolbar() {
  return (
    <div>
        <button>a</button>
        <button>b</button>
        <button>c</button>
        <button>d</button>
    </div>
  )
}

export default Toolbar