
function Icon() {
  return (
    <span>[🌏]</span>
  )
}

export default Icon