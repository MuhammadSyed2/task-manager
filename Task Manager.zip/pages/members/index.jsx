import React from 'react'

function index() {
  return (
    <>
        <div className='bg-red-300 text-2xl'>The members page here</div>
        <a href = '/'>Home</a>
    </>
  )
}

export default index